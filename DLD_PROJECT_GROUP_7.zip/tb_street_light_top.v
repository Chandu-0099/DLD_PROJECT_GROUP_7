`timescale 1ns/1ps

module tb_street_light_top;

    reg clk;
    reg rst;

    reg [3:0] ir_sensor;
    reg ldr_do;

    wire [3:0] led_pwm;
    wire [1:0] system_state;


    localparam S_DAY = 2'd0;
    localparam S_NIGHT_IDLE = 2'd1;
    localparam S_VEHICLE = 2'd2;
    localparam S_HEAVY = 2'd3;


    // 1 MHz SIMULATION CLOCK

    initial begin
        clk = 0;
    end

    always #500 clk = ~clk;


    // DEVICE UNDER TEST

    street_light_top #(

        .CLK_HZ(1000000),

        .IR_ACTIVE_LOW(0),

        .LDR_DARK_LEVEL(1),

        .DEBOUNCE_MS(1)

    ) DUT (

        .clk(clk),
        .rst(rst),

        .ir_sensor(ir_sensor),
        .ldr_do(ldr_do),

        .led_pwm(led_pwm),
        .system_state(system_state)

    );


    // WAIT TASK

    task wait_ms;

        input integer n;

        begin

            repeat (n * 1000)
                @(posedge clk);

            repeat (3)
                @(posedge clk);

        end

    endtask


    // MAIN TEST SEQUENCE

    initial begin

        $display("================================");
        $display("AUTOMATIC STREET LIGHT TEST");
        $display("================================");


        // INITIAL CONDITIONS

        rst = 1;

        ir_sensor = 4'b0000;

        ldr_do = 0;


        repeat (10)
            @(negedge clk);

        rst = 0;


        // TEST 1: DAYLIGHT

        $display("TEST 1: DAYLIGHT");

        wait_ms(5);

        if (system_state !== S_DAY) begin
            $display("FAILED: Daylight state");
            $finish;
        end

        if (DUT.duty_z1 !== 0 ||
            DUT.duty_z2 !== 0 ||
            DUT.duty_z3 !== 0 ||
            DUT.duty_z4 !== 0) begin

            $display("FAILED: Daylight brightness");
            $finish;

        end

        $display("PASSED: All lights OFF");


        // TEST 2: NIGHTTIME

        $display("TEST 2: NIGHTTIME");

        @(negedge clk);
        ldr_do = 1;

        wait_ms(5);

        if (system_state !== S_NIGHT_IDLE) begin
            $display("FAILED: Nighttime state");
            $finish;
        end

        if (DUT.duty_z1 !== 30 ||
            DUT.duty_z2 !== 30 ||
            DUT.duty_z3 !== 30 ||
            DUT.duty_z4 !== 30) begin

            $display("FAILED: Nighttime brightness");
            $finish;

        end

        $display("PASSED: All lights at 30 percent");


        // TEST 3: VEHICLE IN ZONE 1

        $display("TEST 3: VEHICLE IN ZONE 1");

        @(negedge clk);
        ir_sensor = 4'b0001;

        wait_ms(5);

        if (system_state !== S_VEHICLE) begin
            $display("FAILED: Zone 1 detection");
            $finish;
        end

        if (DUT.duty_z1 !== 100 ||
            DUT.duty_z2 !== 100 ||
            DUT.duty_z3 !== 30 ||
            DUT.duty_z4 !== 30) begin

            $display("FAILED: Zone 1 brightness mapping");
            $finish;

        end

        $display("PASSED: Zones 1 and 2 at 100 percent");


        // TEST 4: VEHICLE IN ZONE 2

        $display("TEST 4: VEHICLE IN ZONE 2");

        @(negedge clk);
        ir_sensor = 4'b0010;

        wait_ms(5);

        if (DUT.duty_z1 !== 30 ||
            DUT.duty_z2 !== 100 ||
            DUT.duty_z3 !== 100 ||
            DUT.duty_z4 !== 30) begin

            $display("FAILED: Zone 2 brightness mapping");
            $finish;

        end

        $display("PASSED: Zones 2 and 3 at 100 percent");


        // TEST 5: HEAVY TRAFFIC

        $display("TEST 5: HEAVY TRAFFIC");

        @(negedge clk);
        ir_sensor = 4'b0111;

        wait_ms(6);

        if (system_state !== S_HEAVY) begin
            $display("FAILED: Heavy traffic state");
            $finish;
        end

        if (DUT.duty_z1 !== 100 ||
            DUT.duty_z2 !== 100 ||
            DUT.duty_z3 !== 100 ||
            DUT.duty_z4 !== 100) begin

            $display("FAILED: Heavy traffic brightness");
            $finish;

        end

        $display("PASSED: All zones at 100 percent");


        // TEST 6: RETURN TO DAYLIGHT

        $display("TEST 6: RETURN TO DAYLIGHT");

        @(negedge clk);
        ldr_do = 0;

        wait_ms(6);

        if (system_state !== S_DAY) begin
            $display("FAILED: Daylight priority");
            $finish;
        end

        if (DUT.duty_z1 !== 0 ||
            DUT.duty_z2 !== 0 ||
            DUT.duty_z3 !== 0 ||
            DUT.duty_z4 !== 0) begin

            $display("FAILED: Lights did not turn OFF");
            $finish;

        end

        $display("PASSED: All lights OFF");


        // FINAL RESULT

        $display("================================");
        $display("ALL TESTS PASSED");
        $display("================================");

        $finish;

    end

endmodule