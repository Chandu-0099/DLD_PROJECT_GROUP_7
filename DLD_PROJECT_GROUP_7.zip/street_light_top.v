`timescale 1ns/1ps

module street_light_top #(

    parameter integer CLK_HZ = 100000000,
    parameter integer IR_ACTIVE_LOW = 1,
    parameter integer LDR_DARK_LEVEL = 0,
    parameter integer DEBOUNCE_MS = 10

)(

    input wire clk,
    input wire rst,

    input wire [3:0] ir_sensor,
    input wire ldr_do,

    output wire [3:0] led_pwm,
    output wire [1:0] system_state

);


    // INTERNAL SIGNALS

    wire tick_1ms;

    wire [3:0] vehicle_present;

    wire ldr_dark;
    wire night_mode;

    wire vehicle_any;

    wire [3:0] bright_zones;

    wire [2:0] vehicle_count;

    wire heavy_traffic;

    wire [1:0] state;


    // BRIGHTNESS VALUES

    reg [7:0] duty_z1;
    reg [7:0] duty_z2;
    reg [7:0] duty_z3;
    reg [7:0] duty_z4;


    // FSM STATES

    localparam S_DAY = 2'd0;
    localparam S_NIGHT_IDLE = 2'd1;
    localparam S_VEHICLE = 2'd2;
    localparam S_HEAVY = 2'd3;


    // 1. CLOCK DIVIDER

    clock_divider #(
        .CLK_HZ(CLK_HZ),
        .TICK_HZ(1000)
    ) U1 (

        .clk(clk),
        .rst(rst),
        .tick_1ms(tick_1ms)

    );


    // 2. SENSOR INTERFACE

    sensor_interface #(

        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS),
        .IR_ACTIVE_LOW(IR_ACTIVE_LOW),
        .LDR_DARK_LEVEL(LDR_DARK_LEVEL)

    ) U2 (

        .clk(clk),
        .rst(rst),

        .ir_raw(ir_sensor),
        .ldr_raw(ldr_do),

        .vehicle_present(vehicle_present),
        .ldr_dark(ldr_dark)

    );


    // 3. DAY NIGHT DETECTOR

    day_night_detector U3 (

        .clk(clk),
        .rst(rst),
        .tick_1ms(tick_1ms),

        .ldr_dark(ldr_dark),

        .night_mode(night_mode)

    );


    // 4. VEHICLE DETECTOR

    vehicle_detector U4 (

        .vehicle_present(vehicle_present),

        .vehicle_any(vehicle_any),

        .bright_zones(bright_zones)

    );


    // 5. TRAFFIC COUNTER

    traffic_counter U5 (

        .clk(clk),
        .rst(rst),
        .tick_1ms(tick_1ms),

        .vehicle_present(vehicle_present),

        .vehicle_count(vehicle_count),

        .heavy_traffic(heavy_traffic)

    );


    // 6. FSM CONTROLLER

    fsm_controller U6 (

        .clk(clk),
        .rst(rst),
        .tick_1ms(tick_1ms),

        .night_mode(night_mode),

        .vehicle_any(vehicle_any),

        .heavy_traffic(heavy_traffic),

        .state(state)

    );


    // 7. BRIGHTNESS CONTROL

    always @(*) begin

        duty_z1 = 0;
        duty_z2 = 0;
        duty_z3 = 0;
        duty_z4 = 0;

        case (state)

            // DAYTIME

            S_DAY: begin

                duty_z1 = 0;
                duty_z2 = 0;
                duty_z3 = 0;
                duty_z4 = 0;

            end


            // NIGHTTIME - NO VEHICLES

            S_NIGHT_IDLE: begin

                duty_z1 = 30;
                duty_z2 = 30;
                duty_z3 = 30;
                duty_z4 = 30;

            end


            // VEHICLE DETECTED

            S_VEHICLE: begin

                duty_z1 =
                    bright_zones[0] ? 100 : 30;

                duty_z2 =
                    bright_zones[1] ? 100 : 30;

                duty_z3 =
                    bright_zones[2] ? 100 : 30;

                duty_z4 =
                    bright_zones[3] ? 100 : 30;

            end


            // HEAVY TRAFFIC

            S_HEAVY: begin

                duty_z1 = 100;
                duty_z2 = 100;
                duty_z3 = 100;
                duty_z4 = 100;

            end


            default: begin

                duty_z1 = 0;
                duty_z2 = 0;
                duty_z3 = 0;
                duty_z4 = 0;

            end

        endcase

    end


    // 8. PWM GENERATOR

    pwm_generator #(

        .CLK_HZ(CLK_HZ),
        .PWM_HZ(1000)

    ) U7 (

        .clk(clk),
        .rst(rst),

        .duty_z1(duty_z1),
        .duty_z2(duty_z2),
        .duty_z3(duty_z3),
        .duty_z4(duty_z4),

        .pwm_out(led_pwm)

    );


    // OUTPUT STATE

    assign system_state = state;


endmodule