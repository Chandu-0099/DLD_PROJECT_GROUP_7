`timescale 1ns/1ps

module day_night_detector(

    input wire clk,
    input wire rst,
    input wire tick_1ms,
    input wire ldr_dark,

    output reg night_mode

);

    always @(posedge clk) begin

        if (rst)
            night_mode <= 0;

        else if (tick_1ms)
            night_mode <= ldr_dark;

    end

endmodule