`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/14/2026 11:04:12 AM
// Design Name: 
// Module Name: sync_debounce
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


`timescale 1ns/1ps

module sync_debounce #(
    parameter integer CLK_HZ = 100000000,
    parameter integer DEBOUNCE_MS = 10
)(
    input wire clk,
    input wire rst,
    input wire async_in,
    output reg filtered_out
);

    localparam integer MAX_COUNT =
        (CLK_HZ / 1000) * DEBOUNCE_MS;

    localparam integer COUNT_WIDTH =
        (MAX_COUNT <= 1) ? 1 : $clog2(MAX_COUNT + 1);

    reg sync1;
    reg sync2;

    reg [COUNT_WIDTH-1:0] count;

    always @(posedge clk) begin

        if (rst) begin
            sync1 <= 0;
            sync2 <= 0;
        end

        else begin
            sync1 <= async_in;
            sync2 <= sync1;
        end

    end

    always @(posedge clk) begin

        if (rst) begin
            filtered_out <= 0;
            count <= 0;
        end

        else if (sync2 == filtered_out) begin
            count <= 0;
        end

        else if (count >= MAX_COUNT - 1) begin
            filtered_out <= sync2;
            count <= 0;
        end

        else begin
            count <= count + 1'b1;
        end

    end

endmodule


module sensor_interface #(
    parameter integer CLK_HZ = 100000000,
    parameter integer DEBOUNCE_MS = 10,
    parameter integer IR_ACTIVE_LOW = 1,
    parameter integer LDR_DARK_LEVEL = 0
)(
    input wire clk,
    input wire rst,

    input wire [3:0] ir_raw,
    input wire ldr_raw,

    output wire [3:0] vehicle_present,
    output wire ldr_dark
);

    wire [3:0] ir_normalized;
    wire ldr_normalized;

    assign ir_normalized =
        IR_ACTIVE_LOW ? ~ir_raw : ir_raw;

    assign ldr_normalized =
        (ldr_raw == LDR_DARK_LEVEL) ? 1'b1 : 1'b0;


    sync_debounce #(
        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS)
    ) IR1 (
        .clk(clk),
        .rst(rst),
        .async_in(ir_normalized[0]),
        .filtered_out(vehicle_present[0])
    );


    sync_debounce #(
        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS)
    ) IR2 (
        .clk(clk),
        .rst(rst),
        .async_in(ir_normalized[1]),
        .filtered_out(vehicle_present[1])
    );


    sync_debounce #(
        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS)
    ) IR3 (
        .clk(clk),
        .rst(rst),
        .async_in(ir_normalized[2]),
        .filtered_out(vehicle_present[2])
    );


    sync_debounce #(
        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS)
    ) IR4 (
        .clk(clk),
        .rst(rst),
        .async_in(ir_normalized[3]),
        .filtered_out(vehicle_present[3])
    );


    sync_debounce #(
        .CLK_HZ(CLK_HZ),
        .DEBOUNCE_MS(DEBOUNCE_MS)
    ) LDR (
        .clk(clk),
        .rst(rst),
        .async_in(ldr_normalized),
        .filtered_out(ldr_dark)
    );

endmodule
