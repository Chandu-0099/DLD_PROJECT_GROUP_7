`timescale 1ns/1ps

module pwm_generator #(
    parameter integer CLK_HZ = 100000000,
    parameter integer PWM_HZ = 1000
)(

    input wire clk,
    input wire rst,

    input wire [7:0] duty_z1,
    input wire [7:0] duty_z2,
    input wire [7:0] duty_z3,
    input wire [7:0] duty_z4,

    output wire [3:0] pwm_out

);

    localparam integer PERIOD = CLK_HZ / PWM_HZ;

    localparam integer COUNT_WIDTH =
        (PERIOD <= 1) ? 1 : $clog2(PERIOD);

    reg [COUNT_WIDTH-1:0] pwm_count;


    wire [31:0] threshold1 =
        (PERIOD * duty_z1) / 100;

    wire [31:0] threshold2 =
        (PERIOD * duty_z2) / 100;

    wire [31:0] threshold3 =
        (PERIOD * duty_z3) / 100;

    wire [31:0] threshold4 =
        (PERIOD * duty_z4) / 100;


    always @(posedge clk) begin

        if (rst)
            pwm_count <= 0;

        else if (pwm_count == PERIOD - 1)
            pwm_count <= 0;

        else
            pwm_count <= pwm_count + 1'b1;

    end


    assign pwm_out[0] =
        (duty_z1 >= 100) ? 1'b1 :
        (duty_z1 == 0) ? 1'b0 :
        (pwm_count < threshold1);

    assign pwm_out[1] =
        (duty_z2 >= 100) ? 1'b1 :
        (duty_z2 == 0) ? 1'b0 :
        (pwm_count < threshold2);

    assign pwm_out[2] =
        (duty_z3 >= 100) ? 1'b1 :
        (duty_z3 == 0) ? 1'b0 :
        (pwm_count < threshold3);

    assign pwm_out[3] =
        (duty_z4 >= 100) ? 1'b1 :
        (duty_z4 == 0) ? 1'b0 :
        (pwm_count < threshold4);

endmodule
