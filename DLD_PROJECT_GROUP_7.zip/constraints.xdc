#####################################################
# AUTOMATIC STREET LIGHT PROJECT
# REAL DIGITAL BOOLEAN BOARD
# SPARTAN-7 XC7S50
#####################################################

# FPGA CLOCK - 100 MHz

set_property -dict {PACKAGE_PIN F14 IOSTANDARD LVCMOS33} [get_ports {clk}]

create_clock -period 10.000 -name sys_clk [get_ports {clk}]


# RESET - SLIDE SWITCH SW0

set_property -dict {PACKAGE_PIN V2 IOSTANDARD LVCMOS33} [get_ports {rst}]


# PMOD A - IR SENSORS

# IR SENSOR 1 - JA1_P
set_property -dict {PACKAGE_PIN B13 IOSTANDARD LVCMOS33} [get_ports {ir_sensor[0]}]

# IR SENSOR 2 - JA2_P
set_property -dict {PACKAGE_PIN B14 IOSTANDARD LVCMOS33} [get_ports {ir_sensor[1]}]

# IR SENSOR 3 - JA3_P
set_property -dict {PACKAGE_PIN D12 IOSTANDARD LVCMOS33} [get_ports {ir_sensor[2]}]

# IR SENSOR 4 - JA4_P
set_property -dict {PACKAGE_PIN C13 IOSTANDARD LVCMOS33} [get_ports {ir_sensor[3]}]


# LDR SENSOR - JA1_N (PMOD A PIN 7)

set_property -dict {PACKAGE_PIN A13 IOSTANDARD LVCMOS33} [get_ports {ldr_do}]


# PMOD B - MOSFET DRIVER

# ZONE 1
set_property -dict {PACKAGE_PIN B15 IOSTANDARD LVCMOS33} [get_ports {led_pwm[0]}]

# ZONE 2
set_property -dict {PACKAGE_PIN B17 IOSTANDARD LVCMOS33} [get_ports {led_pwm[1]}]

# ZONE 3
set_property -dict {PACKAGE_PIN B16 IOSTANDARD LVCMOS33} [get_ports {led_pwm[2]}]

# ZONE 4
set_property -dict {PACKAGE_PIN C17 IOSTANDARD LVCMOS33} [get_ports {led_pwm[3]}]


# ONBOARD LEDS - SYSTEM STATE

set_property -dict {PACKAGE_PIN G1 IOSTANDARD LVCMOS33} [get_ports {system_state[0]}]

set_property -dict {PACKAGE_PIN G2 IOSTANDARD LVCMOS33} [get_ports {system_state[1]}]


# FPGA CONFIGURATION

set_property CFGBVS VCCO [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]


#####################################################
# END OF XDC
#####################################################