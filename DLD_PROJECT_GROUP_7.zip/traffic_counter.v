`timescale 1ns/1ps

module traffic_counter(

    input wire clk,
    input wire rst,
    input wire tick_1ms,

    input wire [3:0] vehicle_present,

    output reg [2:0] vehicle_count,
    output wire heavy_traffic

);

    wire [2:0] count_now;

    assign count_now =
        {2'b00, vehicle_present[0]} +
        {2'b00, vehicle_present[1]} +
        {2'b00, vehicle_present[2]} +
        {2'b00, vehicle_present[3]};


    always @(posedge clk) begin

        if (rst)
            vehicle_count <= 0;

        else if (tick_1ms)
            vehicle_count <= count_now;

    end

    assign heavy_traffic = (vehicle_count >= 3);

endmodule