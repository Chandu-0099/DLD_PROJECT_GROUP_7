`timescale 1ns/1ps

module fsm_controller(

    input wire clk,
    input wire rst,
    input wire tick_1ms,

    input wire night_mode,
    input wire vehicle_any,
    input wire heavy_traffic,

    output reg [1:0] state

);

    localparam S_DAY = 2'd0;
    localparam S_NIGHT_IDLE = 2'd1;
    localparam S_VEHICLE = 2'd2;
    localparam S_HEAVY = 2'd3;

    reg [1:0] next_state;


    always @(*) begin

        if (!night_mode)
            next_state = S_DAY;

        else if (heavy_traffic)
            next_state = S_HEAVY;

        else if (vehicle_any)
            next_state = S_VEHICLE;

        else
            next_state = S_NIGHT_IDLE;

    end


    always @(posedge clk) begin

        if (rst)
            state <= S_DAY;

        else if (tick_1ms)
            state <= next_state;

    end

endmodule