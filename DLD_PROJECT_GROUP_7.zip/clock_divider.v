`timescale 1ns/1ps

module clock_divider #(
    parameter integer CLK_HZ = 100000000,
    parameter integer TICK_HZ = 1000
)(
    input wire clk,
    input wire rst,
    output reg tick_1ms
);

    localparam integer DIVISOR = CLK_HZ / TICK_HZ;

    localparam integer COUNT_WIDTH =
        (DIVISOR <= 1) ? 1 : $clog2(DIVISOR);

    reg [COUNT_WIDTH-1:0] count;

    always @(posedge clk) begin

        if (rst) begin
            count <= 0;
            tick_1ms <= 0;
        end

        else if (count == DIVISOR - 1) begin
            count <= 0;
            tick_1ms <= 1;
        end

        else begin
            count <= count + 1'b1;
            tick_1ms <= 0;
        end

    end

endmodule