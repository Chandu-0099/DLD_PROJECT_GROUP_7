`timescale 1ns/1ps

module vehicle_detector(

    input wire [3:0] vehicle_present,

    output wire vehicle_any,
    output wire [3:0] bright_zones

);

    assign vehicle_any = |vehicle_present;

    // Zone 1
    assign bright_zones[0] = vehicle_present[0];

    // Zone 2
    assign bright_zones[1] =
        vehicle_present[0] | vehicle_present[1];

    // Zone 3
    assign bright_zones[2] =
        vehicle_present[1] | vehicle_present[2];

    // Zone 4
    assign bright_zones[3] =
        vehicle_present[2] | vehicle_present[3];

endmodule