`timescale 1ns/1ps

module sensor_interface #(
    parameter integer CLK_HZ = 100_000_000,
    parameter integer DEBOUNCE_MS = 10,
    parameter integer IR_ACTIVE_LOW = 1,
    parameter integer LDR_DARK_LEVEL = 0
)(
    input wire clk,
    input wire rst,

    input wire [3:0] ir_raw,
    input wire ldr_raw,

    output wire [3:0] vehicle_present,
    output wire ldr_dark
);

    localparam integer DEBOUNCE_COUNT =
        (CLK_HZ / 1000) * DEBOUNCE_MS;

    localparam integer COUNT_W =
        (DEBOUNCE_COUNT <= 1) ?
        1 : $clog2(DEBOUNCE_COUNT + 1);

    wire [4:0] normalized_raw;

    assign normalized_raw[3:0] =
        IR_ACTIVE_LOW ? ~ir_raw : ir_raw;

    assign normalized_raw[4] =
        (ldr_raw == LDR_DARK_LEVEL);

    reg [4:0] sync_ff1;
    reg [4:0] sync_ff2;
    reg [4:0] stable_value;

    reg [COUNT_W-1:0] debounce_count [0:4];

    genvar i;

    generate
        for (i = 0; i < 5; i = i + 1) begin : INPUT_FILTER

            always @(posedge clk) begin
                if (rst) begin
                    sync_ff1[i] <= 0;
                    sync_ff2[i] <= 0;
                end
                else begin
                    sync_ff1[i] <= normalized_raw[i];
                    sync_ff2[i] <= sync_ff1[i];
                end
            end

            always @(posedge clk) begin
                if (rst) begin
                    stable_value[i] <= 0;
                    debounce_count[i] <= 0;
                end
                else if (sync_ff2[i] == stable_value[i]) begin
                    debounce_count[i] <= 0;
                end
                else if (debounce_count[i] >= DEBOUNCE_COUNT - 1) begin
                    stable_value[i] <= sync_ff2[i];
                    debounce_count[i] <= 0;
                end
                else begin
                    debounce_count[i] <=
                        debounce_count[i] + 1'b1;
                end
            end

        end
    endgenerate

    assign vehicle_present = stable_value[3:0];
    assign ldr_dark = stable_value[4];

endmodule